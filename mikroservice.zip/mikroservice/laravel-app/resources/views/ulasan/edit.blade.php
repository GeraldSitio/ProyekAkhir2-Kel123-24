<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Ulasan</title>
</head>
<body>
    <h1>Edit Ulasan</h1>

    @if($errors->any())
        <div style="color: red;">
            <ul>
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('ulasan.update', ['id' => $ulasan['id']]) }}" method="post">
        @csrf
        @method('PUT')
        <div>
            <label for="isiUlasan">Isi Ulasan:</label><br>
            <textarea id="isiUlasan" name="isiUlasan" rows="4" cols="50">{{ $ulasan['isi_ulasan'] }}</textarea>
        </div>
        <br>
        <button type="submit">Update Ulasan</button>
    </form>
</body>
</html>
