<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<div class="container">
        @if(session('status'))
            <div class="alert alert-success">{{ session('status') }}</div>
        @endif

        @if(session('error'))
            <div class="alert alert-danger">{{ session('error') }}</div>
        @endif

        <h1>Daftar Artikel</h1>

        <table class="table">
            <thead>
                <tr>
                    <th>Nama</th>
                    <th>Konten</th>
                    <th>Kategori</th>
                    <th>Gambar</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
            @foreach($artikels as $artikel)
    <tr>
        <td>{{ $artikel['nama'] }}</td>
        <td>{{ $artikel['konten'] }}</td>
        <td>{{ $artikel['kategori'] }}</td> <!-- Akses nama kategori -->
        <td>{{ $artikel['gambar'] }}</td>
        <td>
            <a href="{{ route('artikel.edit', $artikel['id']) }}" class="btn btn-primary">Edit</a>
            <form action="{{ route('artikel.destroy', $artikel['id']) }}" method="POST" style="display: inline-block;">
                @csrf
                @method('DELETE')
                <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this artikel?')">Delete</button>
            </form>
        </td>
    </tr>
@endforeach

            </tbody>
        </table>
    </div>
</body>
</html>