<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Obat</title>
</head>
<body>
    <h1>Edit Obat</h1>
    
    @if($errors->any())
        <div>
            <ul>
                @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form action="{{ route('obat.update', $obat['id']) }}" method="POST">
    @csrf
    @method('PUT')
    <div class="form-group">
        <label for="nama">Nama</label>
        <input type="text" name="nama" class="form-control" id="nama" value="{{ $obat['nama'] }}" required>
    </div>
    <div class="form-group">
        <label for="expiredDate">Expired Date</label>
        <input type="date" name="expiredDate" class="form-control" id="expiredDate" value="{{ date('Y-m-d\TH:i:s', strtotime($obat['expiredDate'])) }}" required>
    </div>
    <div class="form-group">
        <label for="jumlahStok">Jumlah Stok</label>
        <input type="number" name="jumlahStok" class="form-control" id="jumlahStok" value="{{ $obat['jumlahStok'] }}" required>
    </div>
    <div class="form-group">
        <label for="deskripsi">Deskripsi</label>
        <textarea name="deskripsi" class="form-control" id="deskripsi" required>{{ $obat['deskripsi'] }}</textarea>
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
</form>
</body>
</html>
