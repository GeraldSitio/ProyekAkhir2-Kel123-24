<!DOCTYPE html>
<html>
<head>
    <title>Edit FAQ</title>
</head>
<body>
    <h1>Edit FAQ</h1>

    <?php if($errors->any()): ?>
        <div style="color: red">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('faq.update', $faq['id'])); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div>
            <label for="pertanyaan">Pertanyaan:</label>
            <input type="text" id="pertanyaan" name="pertanyaan" value="<?php echo e($faq['pertanyaan']); ?>">
        </div>
        <div>
            <label for="jawaban">Jawaban:</label>
            <input type="text" id="jawaban" name="jawaban" value="<?php echo e($faq['jawaban']); ?>">
        </div>
        <button type="submit">Simpan Perubahan</button>
    </form>
</body>
</html>
<?php /**PATH C:\Users\SABAR MARTUA TAMBA\Proyek PASTI\Microservices\mikroservice\laravel-app\resources\views/faq/edit.blade.php ENDPATH**/ ?>