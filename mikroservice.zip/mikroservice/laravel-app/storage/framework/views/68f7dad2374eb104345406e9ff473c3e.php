<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Ulasan</title>
</head>

<body>
    <h1>Daftar Ulasan</h1>

    <?php if(session('success')): ?>
    <div style="color: green;"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if(session('error')): ?>
    <div style="color: red;"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <a href="<?php echo e(route('ulasan.create')); ?>">Tambah Ulasan</a>

    <?php if(isset($ulasans['data']) && is_array($ulasans['data']) && count($ulasans['data']) > 0): ?>
    <table border="1">
        <thead>
            <tr>
                <th>User Name</th>
                <th>Isi Ulasan</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $ulasans['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ulasan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($ulasan['user_id']); ?></td> <!-- Ganti dengan nama pengguna jika tersedia -->
                    <td><?php echo e($ulasan['isi_ulasan']); ?></td>
                    <td>
                        <a href="<?php echo e(route('ulasan.edit', ['id' => $ulasan['id']])); ?>">Edit</a>
                        <form action="<?php echo e(route('ulasan.destroy', ['id' => $ulasan['id']])); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" onclick="return confirm('Are you sure?')">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php else: ?>
    <p>No data available</p>
<?php endif; ?>


</body>

</html><?php /**PATH C:\Users\SABAR MARTUA TAMBA\Proyek PASTI\Microservices\mikroservice\laravel-app\resources\views/ulasan/index.blade.php ENDPATH**/ ?>