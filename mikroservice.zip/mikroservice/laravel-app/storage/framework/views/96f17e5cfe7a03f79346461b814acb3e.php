<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Error</title>
</head>
<body>
    <div class="container">
        <div class="alert alert-danger" role="alert">
            <?php echo e($message); ?>

        </div>
    </div>
</body>
</html>
<?php /**PATH C:\Users\SABAR MARTUA TAMBA\Proyek PASTI\Microservices\mikroservice\laravel-app\resources\views/error.blade.php ENDPATH**/ ?>