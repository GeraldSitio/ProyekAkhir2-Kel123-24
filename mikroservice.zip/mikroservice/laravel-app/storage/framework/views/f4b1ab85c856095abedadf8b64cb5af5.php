<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Obat</title>
</head>
<body>
    <h1>Edit Obat</h1>
    
    <?php if($errors->any()): ?>
        <div>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('obat.update', $obat['id'])); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="form-group">
        <label for="nama">Nama</label>
        <input type="text" name="nama" class="form-control" id="nama" value="<?php echo e($obat['nama']); ?>" required>
    </div>
    <div class="form-group">
        <label for="expiredDate">Expired Date</label>
        <input type="date" name="expiredDate" class="form-control" id="expiredDate" value="<?php echo e(date('Y-m-d\TH:i:s', strtotime($obat['expiredDate']))); ?>" required>
    </div>
    <div class="form-group">
        <label for="jumlahStok">Jumlah Stok</label>
        <input type="number" name="jumlahStok" class="form-control" id="jumlahStok" value="<?php echo e($obat['jumlahStok']); ?>" required>
    </div>
    <div class="form-group">
        <label for="deskripsi">Deskripsi</label>
        <textarea name="deskripsi" class="form-control" id="deskripsi" required><?php echo e($obat['deskripsi']); ?></textarea>
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
</form>
</body>
</html>
<?php /**PATH C:\Users\SABAR MARTUA TAMBA\Proyek PASTI\Microservices\mikroservice\laravel-app\resources\views/obat/edit.blade.php ENDPATH**/ ?>