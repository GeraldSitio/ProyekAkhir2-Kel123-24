<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Artikel</title>
</head>
<body>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Edit Artikel</div>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('artikel.update', $artikel['id'])); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="form-group">
                            <label for="nama">Nama Artikel</label>
                            <input type="text" name="nama" class="form-control" value="<?php echo e($artikel['nama']); ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="konten">Konten Artikel</label>
                            <textarea name="konten" class="form-control" required><?php echo e($artikel['konten']); ?></textarea>
                        </div>

                        <div class="form-group">
                            <label for="kategori_id">Kategori Artikel</label>
                            <select name="kategori_id" class="form-control" required>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category['id']); ?>" <?php echo e($category['id'] == $artikel['kategori_id'] ? 'selected' : ''); ?>>
                                        <?php echo e($category['nama']); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="gambar">Gambar Artikel</label>
                            <input type="file" name="gambar" class="form-control">
                            <img src="<?php echo e(asset('uploads/images/' . $artikel['gambar'])); ?>" alt="<?php echo e($artikel['nama']); ?>" style="max-width: 300px;">
                        </div>

                        <button type="submit" class="btn btn-primary">Update Artikel</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
<?php /**PATH C:\Users\SABAR MARTUA TAMBA\Proyek PASTI\Microservices\mikroservice\laravel-app\resources\views/artikel/edit.blade.php ENDPATH**/ ?>