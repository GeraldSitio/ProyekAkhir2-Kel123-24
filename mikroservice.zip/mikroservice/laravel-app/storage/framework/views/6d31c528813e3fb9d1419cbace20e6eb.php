<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Ulasan Baru</title>
</head>
<body>
    <h1>Tambah Ulasan Baru</h1>

    <?php if($errors->any()): ?>
        <div style="color: red;">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('ulasan.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div>
            <label for="isiUlasan">Isi Ulasan:</label><br>
            <textarea id="isiUlasan" name="isiUlasan" rows="4" cols="50"></textarea>
        </div>
        <br>
        <button type="submit">Tambah Ulasan</button>
    </form>
</body>
</html>
<?php /**PATH C:\Users\SABAR MARTUA TAMBA\Proyek PASTI\Microservices\mikroservice\laravel-app\resources\views/ulasan/create.blade.php ENDPATH**/ ?>