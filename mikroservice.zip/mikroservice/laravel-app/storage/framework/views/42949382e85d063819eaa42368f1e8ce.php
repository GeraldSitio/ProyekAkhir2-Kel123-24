<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">Edit Cuti Dokter</div>

                    <div class="card-body">
                        <form action="<?php echo e(route('cuti-dokter.update', $cutiDokter['id'])); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                            <div class="form-group">
                                <label for="tanggalMulai">Tanggal Mulai</label>
                                <input type="date" name="tanggalMulai" id="tanggalMulai" class="form-control" value="<?php echo e($cutiDokter['tanggalMulai']); ?>" required>
                            </div>

                            <div class="form-group">
                                <label for="tanggalSelesai">Tanggal Selesai</label>
                                <input type="date" name="tanggalSelesai" id="tanggalSelesai" class="form-control" value="<?php echo e($cutiDokter['tanggalSelesai']); ?>" required>
                            </div>

                            <div class="form-group">
                                <label for="keterangan">Keterangan</label>
                                <textarea name="keterangan" id="keterangan" class="form-control" required><?php echo e($cutiDokter['keterangan']); ?></textarea>
                            </div>

                            <button type="submit" class="btn btn-primary">Simpan</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html><?php /**PATH C:\Users\SABAR MARTUA TAMBA\Proyek PASTI\Microservices\mikroservice\laravel-app\resources\views/cuti-dokter/edit.blade.php ENDPATH**/ ?>