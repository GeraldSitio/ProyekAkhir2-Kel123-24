<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<div class="container">
        <?php if(session('status')): ?>
            <div class="alert alert-success"><?php echo e(session('status')); ?></div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
        <?php endif; ?>

        <h1>Daftar Artikel</h1>

        <table class="table">
            <thead>
                <tr>
                    <th>Nama</th>
                    <th>Konten</th>
                    <th>Kategori</th>
                    <th>Gambar</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $artikels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artikel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($artikel['nama']); ?></td>
        <td><?php echo e($artikel['konten']); ?></td>
        <td><?php echo e($artikel['kategori']); ?></td> <!-- Akses nama kategori -->
        <td><?php echo e($artikel['gambar']); ?></td>
        <td>
            <a href="<?php echo e(route('artikel.edit', $artikel['id'])); ?>" class="btn btn-primary">Edit</a>
            <form action="<?php echo e(route('artikel.destroy', $artikel['id'])); ?>" method="POST" style="display: inline-block;">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this artikel?')">Delete</button>
            </form>
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
    </div>
</body>
</html><?php /**PATH C:\Users\SABAR MARTUA TAMBA\Proyek PASTI\Microservices\mikroservice\laravel-app\resources\views/artikel/index.blade.php ENDPATH**/ ?>