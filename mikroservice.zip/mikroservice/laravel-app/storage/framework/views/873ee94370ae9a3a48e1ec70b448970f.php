<!DOCTYPE html>
<html>
<head>
    <title>Ubah Kategori Artikel</title>
</head>
<body>
<h1>Edit Kategori Artikel</h1>
    
    <form action="<?php echo e(route('kategori-artikel.update', $kategoriArtikel['id'])); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group">
            <label for="nama">Nama:</label>
            <input type="text" name="nama" class="form-control" value="<?php echo e($kategoriArtikel['nama']); ?>" required>
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
    </form>
</body>
</html>
<?php /**PATH C:\Users\SABAR MARTUA TAMBA\Proyek PASTI\Microservices\mikroservice\laravel-app\resources\views/kategori-artikel/edit.blade.php ENDPATH**/ ?>