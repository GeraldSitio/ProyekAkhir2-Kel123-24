<!DOCTYPE html>
<html>
<head>
    <title>Detail Kategori Artikel</title>
</head>
<body>
    <h1>Detail Kategori Artikel</h1>
    <p><strong>Nama:</strong> <?php echo e($kategoriArtikel['nama']); ?></p>
</body>
</html>
<?php /**PATH C:\Users\SABAR MARTUA TAMBA\Proyek PASTI\Microservices\mikroservice\laravel-app\resources\views/kategori-artikel/show.blade.php ENDPATH**/ ?>