<!DOCTYPE html>
<html>
<head>
    <title>Daftar FAQ</title>
</head>
<body>
    <h1>Daftar FAQ</h1>

    <?php if(session('success')): ?>
        <div style="color: green"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div style="color: red"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <a href="<?php echo e(route('faq.create')); ?>">Tambah FAQ</a>

    <ul>
        <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <strong>Pertanyaan:</strong> <?php echo e($faq['pertanyaan']); ?> - 
                <strong>Jawaban:</strong> <?php echo e($faq['jawaban']); ?>

                <a href="<?php echo e(route('faq.edit', $faq['id'])); ?>">Edit</a>
                <form action="<?php echo e(route('faq.destroy', $faq['id'])); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit">Hapus</button>
                </form>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</body>
</html>
<?php /**PATH C:\Users\SABAR MARTUA TAMBA\Proyek PASTI\Microservices\mikroservice\laravel-app\resources\views/faq/index.blade.php ENDPATH**/ ?>