<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<h1>Tambah Kategori Artikel</h1>
    
    <form action="<?php echo e(route('kategori-artikel.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="nama">Nama:</label>
            <input type="text" name="nama" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary">Tambah</button>
    </form>
</body>
</html><?php /**PATH C:\Users\SABAR MARTUA TAMBA\Proyek PASTI\Microservices\mikroservice\laravel-app\resources\views/kategori-artikel/create.blade.php ENDPATH**/ ?>