<!DOCTYPE html>
<html>
<head>
    <title>List Kategori Artikels</title>
</head>
<body>
    <h1>Daftar Kategori Artikel</h1>

    <!-- Tambah tombol untuk menambah kategori artikel -->
    <a href="<?php echo e(route('kategori-artikel.create')); ?>" class="btn btn-primary">Tambah Kategori Artikel</a>

    <!-- Tampilkan daftar kategori artikel -->
    <ul>
        <?php $__currentLoopData = $kategoriArtikels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategoriArtikel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($kategoriArtikel['nama']); ?></li>
            <!-- Tambah tombol untuk mengedit dan menghapus kategori artikel -->
            <a href="<?php echo e(route('kategori-artikel.edit', $kategoriArtikel['id'])); ?>" class="btn btn-primary">Edit</a>
            <form action="<?php echo e(route('kategori-artikel.destroy', $kategoriArtikel['id'])); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-danger">Hapus</button>
            </form>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</body>
</html>
<?php /**PATH C:\Users\SABAR MARTUA TAMBA\Proyek PASTI\Microservices\mikroservice\laravel-app\resources\views/kategori-artikel/index.blade.php ENDPATH**/ ?>