<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Antrian</title>
</head>
<body>
    <h1>Daftar Antrian</h1>

    <?php if(session('success')): ?>
        <div><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <table border="1">
        <thead>
            <tr>
                <th>No</th>
                <th>Kepentingan</th>
                <th>Tanggal</th>
                <th>Deskripsi</th>
                <th>Nomor Antrian</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $antrians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $antrian): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($antrian['kepentingan']); ?></td>
                    <td><?php echo e($antrian['tanggal']); ?></td>
                    <td><?php echo e($antrian['deskripsi']); ?></td>
                    <td><?php echo e($antrian['nomorAntrian']); ?></td>
                    <td>
                        <form action="<?php echo e(route('antrian.destroy', $antrian['id'])); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\Users\SABAR MARTUA TAMBA\Proyek PASTI\Microservices\mikroservice\laravel-app\resources\views/antrian/index.blade.php ENDPATH**/ ?>