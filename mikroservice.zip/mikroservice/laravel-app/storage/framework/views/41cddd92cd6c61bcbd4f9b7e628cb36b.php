<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">Daftar Cuti Dokter</div>

                    <div class="card-body">
                        <a href="<?php echo e(route('cuti-dokter.create')); ?>" class="btn btn-primary mb-2">Tambah Cuti Dokter</a>

                        <table class="table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Tanggal Mulai</th>
                                    <th>Tanggal Selesai</th>
                                    <th>Keterangan</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $cutiDokters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cutiDokter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($cutiDokter['id']); ?></td>
                                        <td><?php echo e($cutiDokter['tanggalMulai']); ?></td>
                                        <td><?php echo e($cutiDokter['tanggalSelesai']); ?></td>
                                        <td><?php echo e($cutiDokter['keterangan']); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('cuti-dokter.edit', $cutiDokter['id'])); ?>" class="btn btn-sm btn-warning">Edit</a>
                                            <form action="<?php echo e(route('cuti-dokter.destroy', $cutiDokter['id'])); ?>" method="POST" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus?')">Hapus</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html><?php /**PATH C:\Users\SABAR MARTUA TAMBA\Proyek PASTI\Microservices\mikroservice\laravel-app\resources\views/cuti-dokter/index.blade.php ENDPATH**/ ?>